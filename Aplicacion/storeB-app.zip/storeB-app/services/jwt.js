'use strict'

const jwt = require('jwt-simple')
const moment = require('moment')
const config = require('../config')

exports.createToken = function(employee){
    var payload = {
        sub: employee._id,
        nick: employee.nick,
        role: employee.role,
        email: employee.email,
        iat: moment().unix(),
        exp: moment().add(30,'days').unix()
    }
    return jwt.encode(payload, config.secret)
}