'use strict'

const express = require('express')
const Storecontrollers = require('../controllers/store')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/store/:storeId', md_auth.ensureAuth, Storecontrollers.getStore)
api.get('/stores', md_auth.ensureAuth, Storecontrollers.getStores)
api.post('/store', Storecontrollers.saveStore)
api.post('/register', Storecontrollers.register)
api.put('/store/:storeId', md_auth.ensureAuth, Storecontrollers.updateStore)
api.delete('/store/:storeId', Storecontrollers.deleteStore)

module.exports = api