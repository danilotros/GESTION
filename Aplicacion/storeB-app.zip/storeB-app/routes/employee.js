'use strict'

const express = require('express')
const Employeecontrollers = require('../controllers/employee')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/employee/:employeeId', md_auth.ensureAuth, Employeecontrollers.getEmployee)
api.get('/employees/:storeId?', md_auth.ensureAuth, Employeecontrollers.getEmployees)
api.post('/employee', Employeecontrollers.saveEmployee)
api.post('/login', Employeecontrollers.loginEmployee)
api.put('/employee/:employeeId', md_auth.ensureAuth, Employeecontrollers.updateEmployee)
api.delete('/employee/:employeeId', Employeecontrollers.deleteEmployee)

module.exports = api