'use strict'

const express = require('express')
const Customercontrollers = require('../controllers/customer')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/customer/:customerId', md_auth.ensureAuth, Customercontrollers.getCustomer)
api.get('/customers/:storeId?', md_auth.ensureAuth, Customercontrollers.getCustomers)
api.post('/customer', md_auth.ensureAuth, Customercontrollers.saveCustomer)
api.put('/customer/:customerId', md_auth.ensureAuth, Customercontrollers.updateCustomer)
api.delete('/customer/:customerId', md_auth.ensureAuth, Customercontrollers.deleteCustomer)

module.exports = api