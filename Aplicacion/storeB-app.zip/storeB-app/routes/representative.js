'use strict'

const express = require('express')
const Representativecontrollers = require('../controllers/representative')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/representative/:representativeId', md_auth.ensureAuth, Representativecontrollers.getRepresentative)
api.get('/representatives/:providerId?', md_auth.ensureAuth, Representativecontrollers.getRepresentatives)
api.post('/representative', md_auth.ensureAuth, Representativecontrollers.saveRepresentative)
api.put('/representative/:representativeId', md_auth.ensureAuth, Representativecontrollers.updateRepresentive)
api.delete('/representative/:representativeId', md_auth.ensureAuth, Representativecontrollers.deleteRepresentative)

module.exports = api