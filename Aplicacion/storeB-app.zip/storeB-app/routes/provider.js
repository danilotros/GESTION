'use strict'

const express = require('express')
const Providercontrollers = require('../controllers/provider')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/provider/:providerId', md_auth.ensureAuth, Providercontrollers.getProvider)
api.get('/providers/:storeId?', md_auth.ensureAuth, Providercontrollers.getProviders)
api.post('/provider', md_auth.ensureAuth, Providercontrollers.saveProvider)
api.put('/provider/:providerId', md_auth.ensureAuth, Providercontrollers.updateProvider)
api.delete('/provider/:providerId', md_auth.ensureAuth, Providercontrollers.deleteProvider)

module.exports = api