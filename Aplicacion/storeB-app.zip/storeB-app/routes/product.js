'use strict'

const express = require('express')
const Productcontrollers = require('../controllers/product')

const api = express.Router()
const md_auth = require('../middlewares/authentication')

api.get('/product/:productId', md_auth.ensureAuth, Productcontrollers.getProduct)
api.get('/products/:storeId?', md_auth.ensureAuth, Productcontrollers.getProducts)
api.post('/product', md_auth.ensureAuth, Productcontrollers.saveProduct)
api.put('/product/:productId', md_auth.ensureAuth, Productcontrollers.updateProduct)
api.delete('/product/:productId', md_auth.ensureAuth, Productcontrollers.deleteProduct)

module.exports = api