'use strict'

const Provider = require('../models/provider')

function getProvider(req, res) {
    let providerId = req.params.providerId

    Provider.findById(providerId).populate({ path: 'store' }).exec((err, provider) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!provider) {
                res.status(404).send({ message: 'No Provider' })
            } else {
                res.status(200).send(provider)
            }
        }
    })
}

function getProviders(req, res) {
    let storeId = req.params.storeId
    if (!storeId) {
        var find = Provider.find({})
    } else {
        var find = Provider.find({ store: storeId }).sort('name')
    }
    find.populate({ path: 'store' }).exec((err, providers) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!providers) {
                res.status(404).send({ message: 'No Providers' })
            } else {
                res.status(200).send({providers:providers})
            }
        }
    })
}

function saveProvider(req, res) {
    let provider = new Provider()

    provider.name = req.body.name
    provider.nit = req.body.nit
    provider.phone = req.body.phone
    provider.address = req.body.address
    provider.mail = req.body.mail
    provider.state = 1
    provider.store = req.body.store

    provider.save((err, providerStored) => {
        if (err) {
            res.status(500).send({ message: 'Error al guardar en la BD' })
        } else {
            res.status(200).send({provider:providerStored})
        }
    })
}

function updateProvider(req, res) {
    let providerId = req.params.providerId
    let providerUpdate = req.body

    Provider.findByIdAndUpdate(customerId, customerUpdate, (err, providerUpdate) => {
        if (err) {
            res.status(500).send({ message: "Error al procesar la peticion" })
        } else {
            if (!providerUpdate) {
                res.status(404).send({ message: "No se pudo actualizar Provider" })
            } else {
                res.status(200).send(providerUpdate)
            }
        }
    })
}

function deleteProvider(req, res) {

}

module.exports = {
    getProvider,
    getProviders,
    saveProvider,
    updateProvider,
    deleteProvider
}