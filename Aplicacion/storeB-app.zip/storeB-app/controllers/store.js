'use strict'

const bcrypt = require('bcrypt-nodejs')
const Store = require('../models/store')
const Employee = require('../models/employee')

function getStore(req, res) {
    let storeId = req.params.storeId

    Store.findOne({ _id: storeId }, (err, store) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        }
        if (!store) {
            res.status(404).send({ message: 'Store no encontrado' })
        }
        res.status(200).send({ store: store })
    })
}

function getStores(req, res) {
    Store.find({}, (err, stores) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!stores) {
                res.status(404).send({ message: 'No Stores' })
            } else {
                res.status(200).send(stores)
            }
        }
    })
}

function saveStore(req, res) {
    let store = new Store()
    store.name = req.body.name
    store.nit = req.body.nit
    store.type = req.body.type
    store.phone = req.body.phone
    store.address = req.body.address
    store.mail = req.body.mail

    store.save((err, storeStored) => {
        if (err) {
            res.status(500).send({ message: 'Error al guardar en la BD' })
        } else {
            res.status(200).send(storeStored)
        }
    })
}

function updateStore(req, res) {
    let storeId = req.params.storeId
    let storeUpdate = req.body

    Store.findByIdAndUpdate(storeId, storeUpdate, (err, storeUpdate) => {
        if (err) {
            res.status(500).send({ message: "Error al procesar la peticion" })
        } else {
            if (!storeUpdate) {
                res.status(404).send({ message: "No se pudo actualizar la Store" })
            } else {
                res.status(200).send(storeUpdate)
            }
        }
    })

}

function deleteStore(req, res) {

}

function register(req, res) {
    let store = new Store()
    let employee = new Employee()

    store.name = req.body.name
    store.nit = req.body.nit
    store.type = req.body.type
    store.phone = req.body.phone
    store.address = req.body.address
    store.mail = req.body.mail

    employee.name.firstName = req.body.firstname
    employee.name.lastName = req.body.lastname
    employee.document.typeDocument = "Cedula"
    employee.document.description = req.body.document
    employee.role = "Administrador"
    employee.nick = req.body.nick
    employee.access = 1
    employee.phone = req.body.phoneu
    employee.address = req.body.addressu
    employee.mail = req.body.mailu

    if (req.body.password) {
        store.save((err, storeStored) => {
            if (err) {
                res.status(500).send({ message: 'Error al guardar en la BD' })
            } else {
                if (!storeStored) {
                    res.status(404).send({ message: 'Error' })
                } else {
                    employee.store = storeStored._id
                    bcrypt.hash(req.body.password, null, null, function (err, hash) {
                        employee.password = hash
                        employee.save((err, employeeStored) => {
                            if (err) {
                                res.status(500).send({ message: 'Error al guardar en la BD' })
                            } else {
                                res.status(200).send({ store: storeStored, employee: employeeStored })
                            }
                        })
                    })
                }
            }
        })
    }
}

module.exports = {
    getStore,
    getStores,
    saveStore,
    updateStore,
    deleteStore,
    register
}