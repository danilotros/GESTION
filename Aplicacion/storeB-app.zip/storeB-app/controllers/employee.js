'use strict'

const bcrypt = require('bcrypt-nodejs')
const Employee = require('../models/employee')
const jwt = require('../services/jwt')

function getEmployee(req, res) {
    let employeeId = req.params.employeeId

    Employee.findById(employeeId),(err,employee) => {
        if(err){
            res.status(500).send({message: 'Error al realizar la peticion'})
        }else{
            if(!employee){
                res.status(404).send({message:'No Employee'})
            }else{
                res.status(200).send(employee)
            }
        }
    }
}

function getEmployees(req,res){
    let storeId = req.params.storeId
    if (!storeId) {
        var find = Employee.find({})
    } else {
        var find = Employee.find({ store: storeId }).sort('name')
    }
    find.populate({ path: 'store' }).exec((err, employees) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!employees) {
                res.status(404).send({ message: 'No Products' })
            } else {
                res.status(200).send({employees:employees})
            }
        }
    }) 
}

function saveEmployee(req, res) {
    var employee = new Employee()
    
    employee.name.firstName = req.body.firstname
    employee.name.lastName = req.body.lastname
    employee.document.typeDocument = req.body.typeDocument
    employee.document.description = req.body.document
    employee.role = req.body.role
    employee.nick = req.body.nick
    employee.access = 1
    employee.phone = req.body.phone
    employee.address = req.body.address
    employee.mail = req.body.mail
    employee.store = req.body.store

    if (req.body.password) {
        bcrypt.hash(req.body.password, null, null, function (err, hash) {
            employee.password = hash
            employee.save((err, employeeStored) => {
                if (err) {
                    res.status(500).send({ message: 'Error al guardar en la BD' })
                } else {
                    res.status(200).send({employee:employeeStored})
                }
            })
        })
    }

}

function updateEmployee(req, res) {
    let employeeId = req.params.employeeId
    let employeeUpdate = req.body

    Employee.findByIdAndUpdate(employeeId, employeeUpdate,(err, employeeUpdate) => {
        if(err){
            res.status(500).send({message:"Error al procesar la peticion"})
        }else{
            if(!employeeUpdate){
                res.status(404).send({message:"No se pudo actulizar el Empleado"})
            }else{
                res.status(200).send(employeeUpdate)
            }
        }
    })


}

function deleteEmployee(req, res) {

}


function loginEmployee(req,res){
    var nick = req.body.nick
    var password = req.body.password

    Employee.findOne({nick: nick},(err, employee) => {
        if(err){
            res.status(500).send({message:'Error en la peticion'})
        }else{
            if(!employee){
                res.status(404).send({message: 'Empleado no exista'})
            }else{
                bcrypt.compare(password, employee.password, function(err, check){
                    if(check){
                        if(req.body.getHash){
                            res.status(200).send({
                                token: jwt.createToken(employee)
                            })
                        }else{
                            res.status(200).send({employee:employee})
                        }
                    }else{
                        res.status(404).send({message: 'Empleado no se pudo loguear'})
                    }
                })
            }
        }
    })
}

module.exports = {
    getEmployee,
    getEmployees,
    saveEmployee,
    updateEmployee,
    deleteEmployee,
    loginEmployee
}