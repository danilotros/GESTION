'use strict'

const ProviderProduct = require('../models/providerProduct')

function getProviderProduct(req, res) {
    
}

function getProviderProducts(req, res) {
    
}

function saveProviderProduct(req, res) {
    
}

function updateProviderProduct(req, res) {
    
}

function deleteProviderProduct(req, res) {

}

module.exports = {
    getProviderProduct,
    getProviderProducts,
    saveProviderProduct,
    updateProviderProduct,
    deleteProviderProduct
}