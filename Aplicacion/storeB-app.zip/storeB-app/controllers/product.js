'use strict'

const Product = require('../models/product')

function getProduct(req, res) {
    let productId = req.params.productId

    Product.findById(productId).populate({ path: 'store' }).exec((err, product) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!product) {
                res.status(404).send({ message: 'No Product' })
            } else {
                res.status(200).send(product)
            }
        }
    })
}

function getProducts(req, res) {
    let storeId = req.params.storeId
    if (!storeId) {
        var find = Product.find({})
    } else {
        var find = Product.find({ store: storeId }).sort('name')
    }
    find.populate({ path: 'store' }).exec((err, products) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!products) {
                res.status(404).send({ message: 'No Products' })
            } else {
                res.status(200).send({products:products})
            }
        }
    })
}

function saveProduct(req, res) {
    let product = new Product()

    product.name = req.body.name
    product.type = req.body.type
    product.state = 1
    product.store = req.body.store

    product.save((err, productStored) => {
        if (err) {
            res.status(500).send({ message: 'Error al guardar en la BD' })
        } else {
            if(!productStored){
                res.status(404).send({message: 'Error en BD'})
            }else{
                res.status(200).send({product: productStored})
            }
            
        }
    })
}

function updateProduct(req, res) {
    let productId = req.params.productId
    let productUpdate = req.body

    Product.findByIdAndUpdate(productId, productUpdate, (err, productUpdate) => {
        if (err) {
            res.status(500).send({ message: "Error al procesar la peticion" })
        } else {
            if (!productUpdate) {
                res.status(404).send({ message: "No se pudo actualizar Product" })
            } else {
                res.status(200).send(productUpdate)
            }
        }
    })
}

function deleteProduct(req, res) {

}

module.exports = {
    getProduct,
    getProducts,
    saveProduct,
    updateProduct,
    deleteProduct
}