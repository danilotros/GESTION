'use strict'

const Representative = require('../models/representative')

function getRepresentative(req, res) {
    let representativeId = req.params.representativeId

    Representative.findById(representativeId).populate({ path: 'provider' }).exec((err, representative) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!representative) {
                res.status(404).send({ message: 'No Representative' })
            } else {
                res.status(200).send(representative)
            }
        }
    })
}

function getRepresentatives(req, res) {
    let providerId = req.params.providerId
    if (!providerId) {
        var find = Representative.find({})
    } else {
        var find = Representative.find({ provider: providerId }).sort('name')
    }
    find.populate({ path: 'provider' }).exec((err, representatives) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!representatives) {
                res.status(404).send({ message: 'No Representatives' })
            } else {
                res.status(200).send(representatives)
            }
        }
    })
}

function saveRepresentative(req, res) {
    let representative = new Representative()

    representative.name.firstName = req.body.firstname
    representative.name.lastName = req.body.lastname
    representative.document.typeDocument = req.body.type
    representative.document.description = req.body.description
    representative.phone = req.body.phone
    representative.mail = req.body.mail
    representative.provider = req.body.provider

    representative.save((err, representativeStored) => {
        if (err) {
            res.status(500).send({ message: 'Error en la peticion' })
        } else {
            if(!representativeStored){
                res.status(404).send({message: 'Error en BD'})
            }else{
                res.status(200).send(representativeStored)
            }
        }
    })
}

function updateRepresentive(req, res) {
    let representativeId = req.params.representativeId
    let representativeUpdate = req.body

    Representative.findByIdAndUpdate(representativeId, representativeUpdate, (err, representativeUpdate) => {
        if (err) {
            res.status(500).send({ message: "Error al procesar la peticion" })
        } else {
            if (!representativeUpdate) {
                res.status(404).send({ message: "No se pudo actualizar Representative" })
            } else {
                res.status(200).send(representativeUpdate)
            }
        }
    })
}

function deleteRepresentative(req, res) {

}

module.exports = {
    getRepresentative,
    getRepresentatives,
    saveRepresentative,
    updateRepresentive,
    deleteRepresentative
}