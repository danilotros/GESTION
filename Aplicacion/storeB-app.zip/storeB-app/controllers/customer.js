'use strict'

const Customer = require('../models/customer')

function getCustomer(req, res) {
    let customerId = req.params.customerId

    Customer.findById(customerId).populate({ path: 'store' }).exec((err, customer) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!customer) {
                res.status(404).send({ message: 'No Customer' })
            } else {
                res.status(200).send(customer)
            }
        }
    })
}

function getCustomers(req, res) {
    let storeId = req.params.storeId
    if (!storeId) {
        var find = Customer.find({})
    } else {
        var find = Customer.find({ store: storeId }).sort('name')
    }
    find.populate({ path: 'store' }).exec((err, customers) => {
        if (err) {
            res.status(500).send({ message: 'Error al realizar la peticion' })
        } else {
            if (!customers) {
                res.status(404).send({ message: 'No Customers' })
            } else {
                res.status(200).send({customers:customers})
            }
        }
    })
}

function saveCustomer(req, res) {
    let customer = new Customer()

    customer.name.firstName = req.body.firstname
    customer.name.lastName = req.body.lastname
    customer.document.typeDocument = req.body.typeDocument
    customer.document.description = req.body.document
    customer.phone = req.body.phone
    customer.address = req.body.address
    customer.mail = req.body.mail
    customer.store = req.body.store

    customer.save((err, customerStored) => {
        if (err) {
            res.status(500).send({ message: 'Error al guardar en la BD' })
        } else {
            res.status(200).send({customer:customerStored})
        }
    })
}

function updateCustomer(req, res) {
    let customerId = req.params.customerId
    let customerUpdate = req.body

    Customer.findByIdAndUpdate(customerId, customerUpdate, (err, customerUpdate) => {
        if (err) {
            res.status(500).send({ message: "Error al procesar la peticion" })
        } else {
            if (!customerUpdate) {
                res.status(404).send({ message: "No se pudo actualizar Customer" })
            } else {
                res.status(200).send(customerUpdate)
            }
        }
    })
}

function deleteCustomer(req, res) {

}

module.exports = {
    getCustomer,
    getCustomers,
    saveCustomer,
    updateCustomer,
    deleteCustomer
}