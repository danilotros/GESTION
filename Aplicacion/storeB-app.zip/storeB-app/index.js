'use strict'

const mongoose = require('mongoose')
const app = require('./app')
const config = require('./config')


mongoose.connect(config.db,(err,res) =>{
    if(err){
        console.error("Error conectado a la base de datos")
    }else{
        app.listen(config.port, () => {
            console.log('BACKEND STORE RUNNING !!')
        })
    }
})
