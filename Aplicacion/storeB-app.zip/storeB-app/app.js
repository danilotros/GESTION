'use strict'

const express = require('express')
const bodyParser = require('body-parser')
const app = express()

//Routes
var storeRoutes = require('./routes/store')
var employeeRoutes = require('./routes/employee')
var customerRoutes = require('./routes/customer')
var providerRoutes = require('./routes/provider')
var productRoutes = require('./routes/product')
var representativeRoutes = require('./routes/representative')
var providerProductsRoutes = require('./routes/providerProduct')

app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())

app.use('/api',storeRoutes)
app.use('/api',employeeRoutes)
app.use('/api',customerRoutes)
app.use('/api',providerRoutes)
app.use('/api',productRoutes)
app.use('/api',representativeRoutes)
app.use('/api',providerProductsRoutes)

module.exports = app