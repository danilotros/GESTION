'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ProviderProductSchema = Schema({
    provider: { type: Schema.ObjectId, ref: 'Provider'},
    product: { type: Schema.ObjectId, ref: 'Product'},
    purchasePrice: { type: Number, default: 0}
})

module.exports = mongoose.model('ProviderProduct',ProviderProductSchema)