'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const RepresentativeSchema = Schema({
    name: {
        firstName: String,
        lastName: String
    },
    document: {
        typeDocument: String,
        description: String
    },
    phone: String,
    mail: String,
    provider: { type: Schema.ObjectId, ref: 'Provider'}
})

module.exports = mongoose.model('Representative',RepresentativeSchema)