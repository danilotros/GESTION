'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const InvoiceSchema = Schema({
    store: { type: Schema.ObjectId, ref: 'Store'},
    employee: { type: Schema.ObjectId, ref: 'Employee'},
    customer: { type: Schema.ObjectId, ref: 'Customer'},
    type: String,
    date: Date
})

module.exports = mongoose.model('Invoice',InvoiceSchema)