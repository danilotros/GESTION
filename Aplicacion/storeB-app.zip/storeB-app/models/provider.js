'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ProviderSchema = Schema({
    name: String,
    nit: String,
    phone: String,
    address: String,
    mail: String,
    state: Boolean,
    store: { type: Schema.ObjectId, ref: 'Store'}
})

module.exports = mongoose.model('Provider',ProviderSchema)