'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const DetailInvoiceSchema = Schema({
    invoice: { type: Schema.ObjectId, ref: 'Invoice'},
    inventory: { type: Schema.ObjectId, ref: 'Inventory'}
})

module.exports = mongoose.model('DetailInvoice',DetailInvoiceSchema)