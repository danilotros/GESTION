'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const CustomerSchema = Schema({
    name: {
        firstName: String,
        lastName: String
    },
    document: {
        typeDocument: String,
        description: String
    },
    phone: String,
    address: String,
    mail: String,
    store: { type: Schema.ObjectId, ref: 'Store' }
})

module.exports = mongoose.model('Customer', CustomerSchema)