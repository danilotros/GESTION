'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ProductSchema = Schema({
    name: String,
    type: String,
    state: Boolean,
    store: { type: Schema.ObjectId, ref: 'Store'}
})

module.exports = mongoose.model('Product',ProductSchema)