'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const StoreSchema = Schema({
    name: String,
    nit : String,
    type: String,
    phone: String,
    address: String,
    mail: String
})

module.exports = mongoose.model('Store',StoreSchema)